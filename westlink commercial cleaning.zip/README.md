# Westlink GitHub Pages — self-contained subpages

**Fix:** All six subpages have their CSS and image data embedded within their HTML. No separate stylesheet or images folder is needed to display these subpages correctly. The original homepage is preserved.

## Publish
1. Extract this ZIP.
2. Open your repository `commercialcleaning094-ai/westlink-commercial-cleaning`.
3. Upload all 7 HTML files to the repository ROOT (not inside an extra folder), replacing existing files.
4. Commit the changes and wait for GitHub Pages deployment.
5. Refresh with Ctrl+Shift+R or a private window.

All local page hyperlinks must point to sibling HTML files in the repository root. Do not upload the ZIP itself and expect GitHub Pages to extract it.

The included images and stylesheets are optional backups for further editing; the six subpages do not require them for display.
